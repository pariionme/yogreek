export default function Loading(): null {
  return null;
} 